/*
 * Class Wizard cpp
 * Reece Volker, u16312572, 3/09/2016
 */

using namespace std;

#include "Wizard.h"
#include "Spell.h"

void initialiseSpells( Spell* spells, int maxNumberOfSpells ) {
	Spell defaultSpell;
	for(int i = 0; i < maxNumberOfSpells; ++i) {
		spells[i] = defaultSpell;
	}
}

Wizard::Wizard()
{
	numberOfSpells = 0;
	maxNumberOfSpells = 10;
	hasBeenSummoned = false;
	age = 20;
	numberOfLossedSpells = 0;
	hasCompletedTraining = false;

	spells = new Spell[maxNumberOfSpells];
	//initialiseSpells( spells, maxNumberOfSpells );
}

Wizard::Wizard( const Wizard& w )
{
	delete spells;

	numberOfSpells = w.numberOfSpells;
	maxNumberOfSpells = w.maxNumberOfSpells;
	hasBeenSummoned = w.hasBeenSummoned;
	age = w.age;
	numberOfLossedSpells = w.numberOfLossedSpells;

	spells = new Spell[maxNumberOfSpells];
	for(int i = 0; i < maxNumberOfSpells; ++i) {
		spells[i] = w.spells[i];
	}
}

Wizard::~Wizard()
{
	delete spells;
}

void Wizard::addSpell(const Spell& s)
{
	if( numberOfSpells == maxNumberOfSpells ) {	// add a slot to max
		Spell* temp = new Spell [++maxNumberOfSpells];
		initialiseSpells( spells, maxNumberOfSpells );
		for(int i = 0; i < numberOfSpells; ++i) {
			temp[i] = spells[i];
		}
		delete spells;
		spells = temp;
	}

	int emptySpellIndex = -1;

	for(int i = 0; i < maxNumberOfSpells; ++i) {
		if( spells[i].getName() == "" ) {
			emptySpellIndex = i;
			break;
		}
	}

	spells[emptySpellIndex] = s;
	++numberOfSpells;
}

void Wizard::deleteSpell(string name)
{
	int spellIndex = -1;
	for(int i = 0; i < maxNumberOfSpells; ++i) {
		if( spells[i].getName() == name ) {
			spellIndex = i;
			break;
		}
	}
	if( spellIndex == -1 ) {
		return;
	}

	Spell temp;
	spells[spellIndex] = temp;
	--numberOfSpells;
	++numberOfLossedSpells;
}

int Wizard::getNumberOfSpells() const
{
	return numberOfSpells;
}

void Wizard::setMaxNumberOfSpells(int m)
{
	Spell* temp = new Spell[m];
	initialiseSpells( temp, m );
	for(int i = 0; i < m; ++i) {
		if( i < maxNumberOfSpells ) {
			temp[i] = spells[i];
		}
	}

	delete [] spells;
	spells = temp;
}

int Wizard::getMaxNumberOfSpells() const
{
	return maxNumberOfSpells;
}

void Wizard::setAge(int a)
{
	age = a;
}

int Wizard::getAge() const
{
	return age;
}

int Wizard::getNumberOfLossedSpells() const
{
	return numberOfLossedSpells;
}

Spell& Wizard::getSpell(int index) const
{
	if( index > 0 && index < maxNumberOfSpells ) {
		return spells[index];
	}

	return spells[0];
}
