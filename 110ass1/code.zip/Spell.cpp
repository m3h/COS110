using namespace std;

#include "Spell.h"

Spell::Spell( string nameIn, int difficultyLevelIn, int skillLevelIn )
{
	name = nameIn;
	difficultyLevel = difficultyLevelIn;
	skillLevel = skillLevelIn;
}

Spell::~Spell()
{

}

void Spell::setName(string n)
{
	name = n;
}

string Spell::getName() const
{
	return name;
}

void Spell::setDifficultyLevel(int d)
{
	difficultyLevel = d;
}

int Spell::getDifficultyLevel() const
{
	return difficultyLevel;
}

void Spell::setSkillLevel(int s)
{
	if( s > 0 )
		skillLevel = s;
}
