using namespace std;

#include "Hobbit.h"

Hobbit::Hobbit()
{
	name = "Gerald";
}

Hobbit::~Hobbit()
{

}

void Hobbit::setName(string n)
{
	name = n;
}

string Hobbit::getName() const
{
	return name;
}
