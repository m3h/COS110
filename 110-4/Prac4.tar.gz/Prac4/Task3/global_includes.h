#ifndef MY_GLOBAL_INCLUDES
#define MY_GLOBAL_INCLUDES
#include <iomanip>
#include <iostream>
#include <sstream>   
#include <string>
#include <ctype.h>
#endif
